/* global React */
// ─────────────────────────────────────────────────────────────
// Dr. Gabriel Ribeiro Corrêa — animação de marca
// A mandala é o objeto da peça: nasce, respira, se multiplica
// e a câmera atravessa o centro dela para virar de cena.
//
// ESTADOS DE FRONTEIRA (o que faz os cortes sumirem):
//   B0 = papel com a mandala gigante em marca d'água (abre E fecha a peça)
//   B2 = papel, mandala pequena no topo, rotação zerada
//   B3 = campo kraft cheio
// A peça vai até o kraft no meio e VOLTA pro papel no fim:
// o último frame é igual ao primeiro e igual ao fundo da página.
// ─────────────────────────────────────────────────────────────

const { useScene } = window;

// WhatsApp do Gabriel — +55 21 96625-8458
const WA = "5521966258458";
const WA_MSG = encodeURIComponent("Oi, Dr. Gabriel! Gostaria de agendar uma consulta.");
const WA_URL = `https://wa.me/${WA}?text=${WA_MSG}`;

const C = {
  papel: "#F2ECE0", linho: "#E8DFCE", kraft: "#C9B596",
  barro: "#A8896A", salvia: "#8E967A", tinta: "#3B2F23", cafe: "#231A12",
};

// ── tempo & easing (tudo derivado do relógio da cena) ──
const cl = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const seg = (p, a, b) => cl((p - a) / (b - a || 1));
const oCubic = (t) => 1 - Math.pow(1 - t, 3);
const oQuint = (t) => 1 - Math.pow(1 - t, 5);
const oExpo = (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
const iExpo = (t) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10));
const inOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const mix = (a, b, t) => a + (b - a) * t;
const zoom = (a, b, t) => a * Math.pow(b / a, t);          // escala exponencial = sensação de câmera
const beat = (p, a, b, c, d) => oCubic(seg(p, a, b)) * (1 - oCubic(seg(p, c, d))); // entra e sai dentro da cena

// ── peças ──
const Mandala = ({ size, color = C.tinta, opacity = 1, rot = 0, style }) => (
  <div className="mandala" style={{
    width: size, height: size, backgroundColor: color, opacity,
    transform: `rotate(${rot}deg)`, ...style,
  }} />
);

// mandala centralizada em coordenadas de palco
const Centered = ({ children, top = "50%", style }) => (
  <div style={{ position: "absolute", top, left: "50%", transform: "translate(-50%,-50%)", display: "grid", placeItems: "center", ...style }}>
    {children}
  </div>
);

// anéis concêntricos contrarrotativos — só no nascimento da marca
const Bloom = ({ size, rot, opacity = 1, rings = 4, color = C.tinta, spread = 0.62 }) => (
  <>
    {Array.from({ length: rings }).map((_, i) => (
      <Mandala key={i}
        size={`${size * (1 + i * spread)}em`}
        color={color}
        opacity={opacity * (0.9 / (i * 1.5 + 1))}
        rot={rot * (i % 2 ? -1 : 1) * (1 + i * 0.22)}
        style={{ position: "absolute" }} />
    ))}
  </>
);

// ── FRAGMENTOS DA LOGO ──
// recorta regiões da própria mandala via mask-size/position:
// o núcleo, uma pétala e um arco da borda viram figuras autônomas.
const FRAG = {
  nucleo: { z: 3.4, x: 50, y: 50 },   // rosácea central
  petala: { z: 3.6, x: 50, y: 9 },    // pétala de cima
  arco:   { z: 1.9, x: 50, y: 99 },   // arco da borda
  quina:  { z: 2.9, x: 10, y: 10 },   // canto ornamental
};

const Frag = ({ kind = "nucleo", size, color = C.tinta, opacity = 1, rot = 0, style }) => {
  const f = FRAG[kind];
  const mask = {
    WebkitMaskImage: "url('logo-mark.png')", maskImage: "url('logo-mark.png')",
    WebkitMaskSize: `${f.z * 100}%`, maskSize: `${f.z * 100}%`,
    WebkitMaskRepeat: "no-repeat", maskRepeat: "no-repeat",
    WebkitMaskPosition: `${f.x}% ${f.y}%`, maskPosition: `${f.x}% ${f.y}%`,
  };
  return <div style={{ width: size, height: size, backgroundColor: color, opacity, transform: `rotate(${rot}deg)`, ...mask, ...style }} />;
};

// véu sólido — é ele que “engole” a tela no zoom e esconde o corte
const Veil = ({ color, o }) => (
  <div style={{ position: "absolute", inset: 0, background: color, opacity: o, pointerEvents: "none" }} />
);

const Grain = () => (
  <div style={{
    position: "absolute", inset: 0, pointerEvents: "none", mixBlendMode: "multiply", opacity: 0.5,
    backgroundImage: "radial-gradient(rgba(59,47,35,.05) 1px, transparent 1px), radial-gradient(rgba(59,47,35,.035) 1px, transparent 1px)",
    backgroundSize: "3px 3px, 7px 7px", backgroundPosition: "0 0, 1px 1px",
  }} />
);

function Words({ text, p, inA, inB, outA, outB, step = 0.035, style }) {
  const fade = 1 - oCubic(seg(p, outA, outB));
  return (
    <span style={{ display: "inline-flex", flexWrap: "wrap", justifyContent: "center", gap: "0 .26em", ...style }}>
      {text.split(" ").map((w, i) => {
        const a = inA + i * step;
        const t = oQuint(seg(p, a, Math.min(inB, a + 0.3)));
        return <span key={i} style={{ display: "inline-block", opacity: t * fade, transform: `translateY(${mix(18, 0, t)}px)` }}>{w}</span>;
      })}
    </span>
  );
}

const S = {
  stage: { position: "absolute", inset: 0, background: C.papel, overflow: "hidden", fontSize: "var(--u, 18px)" },
  serif: { fontFamily: "'Cormorant Garamond', Georgia, serif", fontWeight: 400 },
  sans: { fontFamily: "'Outfit', system-ui, sans-serif", fontWeight: 300 },
  mark: { position: "absolute", top: "15%", left: "50%", transform: "translate(-50%,-50%)" },
  slot: {
    position: "absolute", top: "38%", left: 0, right: 0, bottom: "8%",
    display: "flex", flexDirection: "column", alignItems: "center",
    padding: "0 8%", textAlign: "center",
  },
};

// ══════════════ 01 · Semente ══════════════
// B0 (papel + mandala gigante em marca d'água) → a câmera recua → marca no topo
function Semente() {
  const { progress: p } = useScene();
  const pull = oExpo(seg(p, 0.02, 0.56));
  const lift = inOut(seg(p, 0.62, 1));
  const rot = mix(-360, 0, oQuint(seg(p, 0, 0.9)));   // volta inteira: -360 ≡ 0 nas duas pontas
  const size = mix(zoom(60, 13, pull), 6, lift);
  const op = mix(0.1, 0.9, oCubic(seg(p, 0.05, 0.62)));
  const top = mix(50, 15, lift);

  return (
    <div style={S.stage}>
      <Centered top={`${top}%`}>
        <Bloom size={size} rot={rot} opacity={0.13 * pull * (1 - lift)} rings={3} spread={0.5} />
        <Mandala size={`${size}em`} rot={rot} opacity={op} style={{ position: "absolute" }} />
      </Centered>
      <Grain />
    </div>
  );
}

// ══════════════ 02 · Premissa ══════════════
// B2 → arco da borda cruza o rodapé, pétala repousa no alto → B2
// sem rotação: só deriva lenta e respiração
function Premissa() {
  const { progress: p } = useScene();
  const arco = beat(p, 0.02, 0.38, 0.86, 1);
  const pet = beat(p, 0.12, 0.46, 0.86, 1);
  const rule = beat(p, 0.24, 0.52, 0.88, 1);
  const glide = mix(-3, 3, p);

  return (
    <div style={S.stage}>
      <Frag kind="arco" size="46em" opacity={0.1 * arco} rot={-4}
        style={{ position: "absolute", left: "50%", top: `${88 + glide * 0.4}%`, transform: `translate(-50%,-50%) rotate(-4deg)` }} />
      <Frag kind="petala" size="16em" opacity={0.09 * pet} color={C.barro}
        style={{ position: "absolute", right: "-3em", top: `${18 + glide}%` }} />

      <div style={S.mark}><Mandala size="6em" opacity={0.9} /></div>
      <div style={S.slot}>
        <div style={{ ...S.serif, fontSize: "3.1em", lineHeight: 1.2, color: C.cafe, letterSpacing: "-0.008em", maxWidth: "18em" }}>
          <Words p={p} text="A cura começa quando nos sentimos" inA={0.06} inB={0.52} outA={0.88} outB={1} />
          <span style={{ display: "block", fontStyle: "italic", color: C.barro, opacity: beat(p, 0.34, 0.62, 0.88, 1) }}>
            genuinamente ouvidos.
          </span>
        </div>
        <div style={{ width: `${mix(0, 6, rule)}em`, height: 1, background: C.barro, opacity: 0.6 * rule, marginTop: "1.8em" }} />
      </div>
      <Grain />
    </div>
  );
}

// ══════════════ 03–05 · Pilares ══════════════
// mesma âncora B2; cada pilar traz um FRAGMENTO diferente da logo, parado ou em deriva lenta
function Pilar({ scene }) {
  const { progress: p } = useScene();
  const num = beat(p, 0.04, 0.26, 0.9, 1);
  const tit = beat(p, 0.1, 0.4, 0.9, 1);
  const txt = beat(p, 0.26, 0.58, 0.88, 1);
  const rule = beat(p, 0.16, 0.48, 0.9, 1);
  const bg = beat(p, 0.02, 0.42, 0.86, 1);
  const breathe = 1 + 0.04 * Math.sin(p * Math.PI);   // respiração, não giro
  const glide = mix(-4, 4, p);

  return (
    <div style={S.stage}>
      {/* i · núcleo respirando ao centro */}
      {scene.visual === "nucleo" && (
        <Centered top="62%">
          <Frag kind="nucleo" size="30em" opacity={0.1 * bg}
            style={{ transform: `translate(-50%,-50%) scale(${breathe})`, position: "absolute", left: "50%", top: "50%" }} />
        </Centered>
      )}

      {/* ii · três pétalas compondo o quadro, entrada escalonada, depois paradas */}
      {scene.visual === "petalas" && [
        { k: "petala", s: "15em", l: "4%", t: "58%", r: -18, d: 0 },
        { k: "petala", s: "11em", l: "82%", t: "38%", r: 24, d: 0.08 },
        { k: "quina", s: "13em", l: "70%", t: "84%", r: 8, d: 0.16 },
      ].map((f, i) => {
        const t = beat(p, 0.06 + f.d, 0.44 + f.d, 0.86, 1);
        return (
          <Frag key={i} kind={f.k} size={f.s} color={i === 1 ? C.barro : C.tinta}
            opacity={0.11 * t} rot={f.r}
            style={{ position: "absolute", left: f.l, top: f.t, transform: `translate(-50%,-50%) rotate(${f.r}deg) translateY(${mix(18, 0, t)}px)` }} />
        );
      })}

      {/* iii · fileira de arcos derivando devagar na horizontal */}
      {scene.visual === "deriva" && (
        <div style={{ position: "absolute", inset: 0, transform: `translateX(${glide}%)` }}>
          {[0, 1, 2, 3].map((i) => (
            <Frag key={i} kind="arco" size="26em" color={i % 2 ? C.barro : C.tinta}
              opacity={0.075 * bg}
              style={{ position: "absolute", left: `${i * 30 - 8}%`, top: `${74 + (i % 2 ? 5 : 0)}%`, transform: "translate(-50%,-50%)" }} />
          ))}
        </div>
      )}

      <div style={S.mark}><Mandala size="6em" opacity={0.9} /></div>

      <div style={S.slot}>
        <div style={{ ...S.serif, fontStyle: "italic", fontSize: "1.5em", color: C.barro, opacity: num, transform: `translateY(${mix(10, 0, num)}px)` }}>
          {scene.num}
        </div>
        <div style={{ width: `${mix(0, 3.4, rule)}em`, height: 2, background: C.kraft, opacity: rule, margin: "1em 0 1.2em" }} />
        <div style={{ ...S.serif, fontSize: "3.4em", lineHeight: 1.05, color: C.cafe, letterSpacing: "-0.01em", opacity: tit, transform: `translateY(${mix(18, 0, tit)}px)` }}>
          {scene.titulo}
        </div>
        <div style={{ ...S.sans, fontSize: "1.18em", lineHeight: 1.62, color: C.tinta, opacity: 0.85 * txt, maxWidth: "24em", marginTop: "1.2em", transform: `translateY(${mix(12, 0, txt)}px)`, textWrap: "pretty" }}>
          {scene.texto}
        </div>
        {scene.selos && (
          <div style={{ display: "flex", gap: ".7em", marginTop: "1.5em", flexWrap: "wrap", justifyContent: "center" }}>
            {scene.selos.map((s, i) => {
              const t = beat(p, 0.46 + i * 0.07, 0.72 + i * 0.07, 0.88, 1);
              return (
                <span key={s} style={{
                  ...S.sans, fontSize: ".72em", letterSpacing: ".26em", textTransform: "uppercase",
                  color: C.tinta, border: `1px solid ${C.barro}`, borderRadius: "99px",
                  padding: ".7em 1.4em", opacity: 0.9 * t, transform: `translateY(${mix(14, 0, t)}px)`,
                }}>{s}</span>
              );
            })}
          </div>
        )}
      </div>
      <Grain />
    </div>
  );
}

// ══════════════ 06 · Formatos ══════════════
function Formatos() {
  const { progress: p } = useScene();
  const bg = beat(p, 0.02, 0.4, 0.88, 1);
  const cards = [
    { tag: "Presencial", nome: "No consultório", nota: "Catete · Rio de Janeiro" },
    { tag: "Online", nome: "Por vídeo", nota: "De onde você estiver" },
  ];
  return (
    <div style={S.stage}>
      <Frag kind="arco" size="52em" opacity={0.075 * bg}
        style={{ position: "absolute", left: "50%", top: "92%", transform: "translate(-50%,-50%)" }} />
      <div style={S.mark}><Mandala size="6em" opacity={0.9} /></div>
      <div style={{ ...S.slot, flexDirection: "row", justifyContent: "center", alignItems: "flex-start", gap: "1.6em", flexWrap: "wrap" }}>
        {cards.map((c, i) => {
          const t = beat(p, 0.08 + i * 0.12, 0.46 + i * 0.12, 0.88, 1);
          return (
            <div key={c.tag} style={{
              flex: "0 1 17em", background: C.linho, border: "1px solid rgba(59,47,35,.16)",
              padding: "1.7em 1.7em 1.8em", textAlign: "left",
              opacity: t, transform: `translateY(${mix(26, 0, t)}px)`,
            }}>
              <div style={{ ...S.sans, fontSize: ".68em", letterSpacing: ".3em", textTransform: "uppercase", color: C.barro, fontWeight: 500 }}>— {c.tag}</div>
              <div style={{ ...S.serif, fontSize: "2em", color: C.cafe, marginTop: ".5em", lineHeight: 1.1 }}>{c.nome}</div>
              <div style={{ ...S.sans, fontSize: ".72em", letterSpacing: ".2em", textTransform: "uppercase", color: C.tinta, opacity: 0.62, marginTop: ".8em" }}>{c.nota}</div>
            </div>
          );
        })}
      </div>
      <Grain />
    </div>
  );
}

// ══════════════ 07 · Assinatura ══════════════
// B2 → a mandala cresce e o papel vira campo kraft → B3
function Assinatura() {
  const { progress: p } = useScene();
  const wash = oCubic(seg(p, 0.06, 0.5));
  const grow = oQuint(seg(p, 0.08, 0.6));
  const rot = mix(-22, 0, oQuint(seg(p, 0, 0.7)));   // assentamento, não giro
  const nome = beat(p, 0.34, 0.66, 0.985, 1);
  const reg = beat(p, 0.5, 0.8, 0.985, 1);

  return (
    <div style={{ ...S.stage }}>
      <div style={{ position: "absolute", inset: 0, opacity: wash, background: `radial-gradient(120% 100% at 50% 34%, #D6C09B 0%, ${C.kraft} 58%, #B9A380 100%)` }} />
      <Centered top={`${mix(15, 34, grow)}%`}>
        <Bloom size={mix(6, 11, grow)} rot={rot} opacity={0.16 * wash * (1 - oCubic(seg(p, 0.84, 1)))} rings={3} spread={0.5} />
        <Mandala size={`${mix(6, 11, grow)}em`} rot={rot} color={wash > 0.5 ? C.cafe : C.tinta} opacity={0.9} style={{ position: "absolute" }} />
      </Centered>
      <div style={{ ...S.slot, top: "58%" }}>
        <div style={{ ...S.serif, fontWeight: 500, fontSize: "2.2em", letterSpacing: ".12em", lineHeight: 1.16, color: C.cafe, opacity: nome, transform: `translateY(${mix(18, 0, nome)}px)` }}>
          GABRIEL RIBEIRO CORRÊA
        </div>
        <div style={{ ...S.sans, fontSize: ".78em", letterSpacing: ".3em", textTransform: "uppercase", color: C.cafe, opacity: 0.75 * reg, marginTop: "1.2em", display: "flex", gap: ".9em", flexWrap: "wrap", justifyContent: "center", transform: `translateY(${mix(12, 0, reg)}px)` }}>
          <span>Psiquiatria</span><span style={{ opacity: 0.5 }}>·</span>
          <span>CRM RJ 113544‑9</span><span style={{ opacity: 0.5 }}>·</span>
          <span>RQE nº 46923</span>
        </div>
      </div>
      <Grain />
    </div>
  );
}

// ══════════════ 08 · Chamada (WhatsApp) ══════════════
// B3 (kraft) → convite + botão → o kraft dissolve e a mandala se abre → B0 (papel)
function Chamada() {
  const { progress: p } = useScene();
  const settle = oCubic(seg(p, 0, 0.24));            // herda a marca da Assinatura
  const linha = beat(p, 0.1, 0.38, 0.6, 0.72);
  const btn = beat(p, 0.28, 0.54, 0.6, 0.72);
  const back = oQuint(seg(p, 0.7, 1));               // volta pro papel

  const size = mix(mix(11, 9, settle), 60, back);
  const top = mix(mix(34, 50, settle), 50, back);
  const op = mix(mix(0.9, 0.14, settle), 0.1, back);
  const rot = mix(0, 360, back);

  return (
    <div style={{ ...S.stage, background: C.papel }}>
      <div style={{ position: "absolute", inset: 0, opacity: 1 - back, background: `radial-gradient(120% 100% at 50% 34%, #D6C09B 0%, ${C.kraft} 58%, #B9A380 100%)` }} />

      <Centered top={`${top}%`}>
        <Mandala size={`${size}em`} rot={rot} color={C.cafe} opacity={op} />
      </Centered>

      <div style={{ ...S.slot, top: "26%" }}>
        <div style={{ ...S.serif, fontSize: "3.2em", lineHeight: 1.14, color: C.cafe, letterSpacing: "-0.01em", maxWidth: "16em", opacity: linha, transform: `translateY(${mix(20, 0, linha)}px)` }}>
          Você não precisa
          <span style={{ display: "block", fontStyle: "italic", color: "#6B4F35" }}>continuar se virando sozinho.</span>
        </div>

        <a href={WA_URL} target="_blank" rel="noopener" style={{
          ...S.sans, marginTop: "2em", display: "inline-flex", alignItems: "center", gap: ".8em",
          background: C.cafe, color: C.papel, textDecoration: "none",
          padding: "1.1em 2em", borderRadius: "99px",
          fontSize: ".82em", letterSpacing: ".22em", textTransform: "uppercase", fontWeight: 500,
          opacity: btn, transform: `translateY(${mix(22, 0, btn)}px) scale(${mix(0.94, 1, btn)})`,
          boxShadow: "0 20px 34px -22px rgba(35,26,18,.8)", pointerEvents: btn > 0.5 ? "auto" : "none",
        }}>
          <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-2.9-1.3-4.8-4.3-5-4.5-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5s.8 2 .9 2.1c.1.2.1.3 0 .5s-.2.4-.3.5l-.4.5c-.2.2-.3.3-.1.6s.7 1.2 1.5 1.9c1 .9 1.9 1.2 2.2 1.3.2.1.4.1.6-.1s.7-.8.9-1.1c.2-.3.4-.2.6-.1l2 1c.3.1.5.2.5.3.1.2.1.7-.1 1.4z" />
          </svg>
          Falar no WhatsApp
        </a>

        <div style={{ ...S.sans, fontSize: ".7em", letterSpacing: ".26em", textTransform: "uppercase", color: C.cafe, opacity: 0.6 * btn, marginTop: "1.4em" }}>
          Resposta pessoal · Presencial no Catete ou por vídeo
        </div>
      </div>

      <Grain />
    </div>
  );
}

Object.assign(window, { Semente, Premissa, Pilar, Formatos, Assinatura, Chamada, Frag, WA_URL });
