# Dr. Gabriel Ribeiro Corrêa — site

Site institucional. Psiquiatria · Rio de Janeiro.

## Publicar no GitHub Pages

Suba **o conteúdo desta pasta** na raiz do repositório `jonrcorrea.github.io`
(branch `main`). O Pages serve automaticamente em `https://jonrcorrea.github.io`.

```
index.html
logo-mark.png
animations-v2.jsx
marca-animacao.jsx
photos/
  gabriel-retrato.png
  consultorio-1.png
  consultorio-2.png
  consultorio-3.png
```

Não há build — é HTML estático. React e Babel vêm de CDN.

## Onde mexer

| O quê | Arquivo |
|---|---|
| Textos, seções, CTAs do site | `index.html` |
| Roteiro da animação (cenas, durações, textos) | bloco `window.OM_SCENES` no fim do `index.html` |
| Movimento das cenas | `marca-animacao.jsx` |
| Número do WhatsApp | constante `WA` no topo do `marca-animacao.jsx` |
| Paleta | bloco `:root` no `index.html` |

## Identidade

Papel `#F2ECE0` · Linho `#E8DFCE` · Kraft `#C9B596` · Barro `#A8896A`
Sálvia `#8E967A` · Malva `#C9BCC4` · Tinta `#3B2F23` · Café `#231A12`

Tipografia: Cormorant Garamond (títulos) + Outfit (corpo).

## Dados profissionais

CRM RJ 113544-9 · RQE nº 46923 · Rua do Catete, 311 — Catete, Rio de Janeiro/RJ
